package com.nokiaclock.widget;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Простой экран-подсказка: как добавить виджет + кнопка быстрого добавления (Android 8+). */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.BLACK);
        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText(R.string.app_name);
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView hint = new TextView(this);
        hint.setText(R.string.hint);
        hint.setTextColor(0xFFBBBBCC);
        hint.setTextSize(16);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, pad, 0, pad);
        root.addView(hint);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Button add = new Button(this);
            add.setText(R.string.add_widget);
            add.setOnClickListener(v -> {
                AppWidgetManager m = getSystemService(AppWidgetManager.class);
                if (m != null && m.isRequestPinAppWidgetSupported()) {
                    m.requestPinAppWidget(
                            new ComponentName(this, ClockWidgetProvider.class), null, null);
                }
            });
            root.addView(add);
        }

        setContentView(root);
    }
}
